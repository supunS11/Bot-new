import os
import time
import logging
import json
import csv
from dataclasses import dataclass
from collections import defaultdict
from typing import Optional

import requests
import pandas as pd
import numpy as np

BINANCE_BASE = "https://fapi.binance.com"
TELEGRAM_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

# ================= CONFIG =================
PAPER_WALLET_USDT = float(os.getenv("PAPER_WALLET_USDT", "3000"))
RISK_PCT = float(os.getenv("RISK_PCT", "0.5"))
MIN_SCORE = int(os.getenv("MIN_SCORE", "75"))
MIN_RR = float(os.getenv("MIN_RR", "2.0"))
MAX_SL_PCT = float(os.getenv("MAX_SL_PCT", "5.0"))
SCAN_SECONDS = int(os.getenv("SCAN_SECONDS", "300"))
REQUEST_DELAY = float(os.getenv("REQUEST_DELAY", "0.12"))
MAX_SYMBOLS = int(os.getenv("MAX_SYMBOLS", "80"))

VP_VALUE_AREA = float(os.getenv("VP_VALUE_AREA", "0.70"))
VP_BINS = int(os.getenv("VP_BINS", "80"))
SL_ATR_BUFFER = float(os.getenv("SL_ATR_BUFFER", "0.25"))
SR_EMA_ENABLED = os.getenv("SR_EMA_ENABLED", "true").lower() in ("1", "true", "yes", "on")
SR_LOOKBACK_15M = int(os.getenv("SR_LOOKBACK_15M", "50"))
SR_NEAR_ATR = float(os.getenv("SR_NEAR_ATR", "0.35"))
CVD_LOOKBACK_5M = int(os.getenv("CVD_LOOKBACK_5M", "20"))  # 20 closed 5m candles = 100 minutes
VP_OF_ABSORPTION_ZONE_ATR = float(os.getenv("VP_OF_ABSORPTION_ZONE_ATR", "0.60"))

# Independent direction-intelligence layer: diagnostic only; main rules stay unchanged.
DIRECTION_INTEL_ENABLED = os.getenv("DIRECTION_INTEL_ENABLED", "true").lower() in ("1", "true", "yes", "on")
DIRECTION_TREND_EMA_FAST = 20
DIRECTION_TREND_EMA_SLOW = 50
DIRECTION_STRUCTURE_LOOKBACK = 20

# Duplicate alert lock: suppress same symbol+direction until old TP/SL boundary is reached.
SIGNAL_RANGE_LOCK_ENABLED = os.getenv("SIGNAL_RANGE_LOCK_ENABLED", "true").lower() in ("1", "true", "yes", "on")
SIGNAL_RANGE_LOCK_PCT = float(os.getenv("SIGNAL_RANGE_LOCK_PCT", "5.0"))
SIGNAL_RANGE_LOCK_FILE = os.getenv("SIGNAL_RANGE_LOCK_FILE", "signal_range_locks.json")

# Paper tracking only: no real orders are placed.
PAPER_TRACKING_ENABLED = os.getenv("PAPER_TRACKING_ENABLED", "true").lower() in ("1", "true", "yes", "on")
PAPER_TRACKING_DIR = os.getenv("PAPER_TRACKING_DIR", ".")
PAPER_TRACKING_CSV = os.path.join(PAPER_TRACKING_DIR, "paper_trades.csv")
PAPER_TRACKING_STATE = os.path.join(PAPER_TRACKING_DIR, "paper_state.json")
PAPER_TRACKING_MAX_HOURS = float(os.getenv("PAPER_TRACKING_MAX_HOURS", "24"))
PAPER_TRACKING_RISK_PCT = float(os.getenv("PAPER_TRACKING_RISK_PCT", "0.5"))



# Deliberately OFF in V1.
AUTO_TRADE = False


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
log = logging.getLogger("HYBRID_V1")
REJECT_COUNTS = defaultdict(int)

def reject(symbol: str, reason: str):
    """Count and log a filter rejection without changing strategy rules."""
    REJECT_COUNTS[reason] += 1
    log.info("REJECT %s | %s", reason, symbol)
    return None


@dataclass
class Signal:
    symbol: str
    side: str
    score: int
    setup: str
    entry: float
    sl: float
    tp: float
    rr: float
    vp_reason: str
    of_reason: str
    cvd_reason: str
    structure_reason: str
    candle_reason: str
    delta: float
    cvd: float
    risk_usdt: float


class BinanceFutures:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "Binance-Hybrid-V1/1.0"})

    def get(self, path, params=None):
        # Binance can return 429 when many symbols are queried too quickly.
        # Retry with exponential backoff instead of failing the whole symbol.
        for attempt in range(5):
            try:
                r = self.session.get(
                    BINANCE_BASE + path,
                    params=params,
                    timeout=15,
                )
                if r.status_code == 429:
                    retry_after = r.headers.get("Retry-After")
                    wait = float(retry_after) if retry_after else (1.5 ** attempt)
                    time.sleep(min(max(wait, 0.5), 10.0))
                    continue
                # HTTP 451 is not a transient rate-limit error. Do not retry it
                # five times; surface the response body in the main-loop handler.
                if r.status_code == 451:
                    raise requests.HTTPError(
                        f"Binance Futures API returned HTTP 451 for {path}",
                        response=r,
                    )
                r.raise_for_status()
                return r.json()
            except requests.RequestException as exc:
                # Retrying an HTTP 451 will not fix a regional/policy restriction.
                if getattr(exc, "response", None) is not None and exc.response.status_code == 451:
                    raise
                if attempt == 4:
                    raise
                time.sleep(min(1.5 ** attempt, 8.0))
        raise RuntimeError("Binance request failed after retries")

    def exchange_info(self):
        return self.get("/fapi/v1/exchangeInfo")

    def ticker_24h(self):
        return self.get("/fapi/v1/ticker/24hr")

    def klines(self, symbol, interval, limit=500):
        return self.get("/fapi/v1/klines", {
            "symbol": symbol, "interval": interval, "limit": limit
        })

    def agg_trades(self, symbol, limit=1000):
        return self.get("/fapi/v1/aggTrades", {
            "symbol": symbol, "limit": limit
        })


def telegram_send(message: str):
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID:
        log.warning("Telegram is not configured.")
        return False

    try:
        r = requests.post(
            f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage",
            json={
                "chat_id": TELEGRAM_CHAT_ID,
                "text": message,
                "parse_mode": "HTML",
                "disable_web_page_preview": True,
            },
            timeout=10,
        )
        r.raise_for_status()
        return True
    except Exception as exc:
        log.error("Telegram error: %s", exc)
        return False


def kline_df(raw):
    cols = [
        "open_time", "open", "high", "low", "close", "volume",
        "close_time", "quote_volume", "trades",
        "taker_buy_base", "taker_buy_quote", "ignore"
    ]
    df = pd.DataFrame(raw, columns=cols)
    for col in [
        "open", "high", "low", "close", "volume",
        "quote_volume", "taker_buy_base", "taker_buy_quote"
    ]:
        df[col] = df[col].astype(float)
    return df


def atr(df, length=14):
    prev = df["close"].shift(1)
    tr = pd.concat([
        df["high"] - df["low"],
        (df["high"] - prev).abs(),
        (df["low"] - prev).abs(),
    ], axis=1).max(axis=1)
    return tr.rolling(length).mean()


# ================= VOLUME PROFILE =================
def volume_profile(df, bins=80, value_area=0.70):
    low = float(df["low"].min())
    high = float(df["high"].max())
    if high <= low:
        return None

    edges = np.linspace(low, high, bins + 1)
    mids = (edges[:-1] + edges[1:]) / 2
    volumes = np.zeros(bins)

    # Practical candle-volume VP approximation.
    bucket = np.clip(
        np.digitize(df["close"].values, edges) - 1,
        0, bins - 1
    )
    for idx, vol in zip(bucket, df["volume"].values):
        volumes[idx] += vol

    poc_idx = int(np.argmax(volumes))
    target = volumes.sum() * value_area

    selected = {poc_idx}
    selected_volume = volumes[poc_idx]
    left, right = poc_idx - 1, poc_idx + 1

    while selected_volume < target and (left >= 0 or right < bins):
        left_v = volumes[left] if left >= 0 else -1
        right_v = volumes[right] if right < bins else -1

        if right_v >= left_v:
            if right < bins:
                selected.add(right)
                selected_volume += right_v
                right += 1
            elif left >= 0:
                selected.add(left)
                selected_volume += left_v
                left -= 1
        else:
            if left >= 0:
                selected.add(left)
                selected_volume += left_v
                left -= 1
            elif right < bins:
                selected.add(right)
                selected_volume += right_v
                right += 1

    nonzero = volumes[volumes > 0]
    if len(nonzero):
        hvn_cut = np.quantile(nonzero, 0.75)
        lvn_cut = np.quantile(nonzero, 0.25)
    else:
        hvn_cut = lvn_cut = 0

    return {
        "poc": float(mids[poc_idx]),
        "vah": float(edges[max(selected) + 1]),
        "val": float(edges[min(selected)]),
        "hvn": [
            float(mids[i]) for i in range(bins)
            if volumes[i] >= hvn_cut and volumes[i] > 0
        ],
        "lvn": [
            float(mids[i]) for i in range(bins)
            if volumes[i] <= lvn_cut and volumes[i] > 0
        ],
    }


# ================= ORDER FLOW =================
def classify_trades(raw):
    for t in raw:
        price = float(t["p"])
        qty = float(t["q"])
        # Binance aggTrades: m=True means buyer was maker,
        # therefore the aggressive taker was a seller.
        aggressive_buy = not bool(t["m"])
        yield int(t["T"]), price, qty, aggressive_buy


def trade_flow(raw):
    buy = sell = 0.0
    for _, _, qty, aggressive_buy in classify_trades(raw):
        if aggressive_buy:
            buy += qty
        else:
            sell += qty
    return buy, sell, buy - sell


def footprint_imbalances(raw):
    levels = defaultdict(lambda: [0.0, 0.0])

    for _, price, qty, aggressive_buy in classify_trades(raw):
        if aggressive_buy:
            levels[price][0] += qty
        else:
            levels[price][1] += qty

    imbalances = []
    for price, (buy, sell) in levels.items():
        if buy > 0 and buy >= 3.0 * sell:
            imbalances.append(("BUY", price, buy, sell))
        elif sell > 0 and sell >= 3.0 * buy:
            imbalances.append(("SELL", price, buy, sell))

    return imbalances


def cvd(df5, lookback=CVD_LOOKBACK_5M):
    """Return rolling CVD in BASE-asset units from CLOSED 5m candles.

    Binance USD-M Futures klines provide:
      - volume: total traded base-asset quantity
      - taker_buy_base: base quantity bought aggressively by takers

    Aggressive sell volume = total volume - aggressive buy volume.
    Per-candle delta = aggressive buy volume - aggressive sell volume
                     = 2 * taker_buy_base - total volume.
    Rolling CVD here is the sum of those deltas over the most recent
    `lookback` CLOSED 5m candles. It is deliberately independent of aggTrades
    `delta`, which is a separate recent-trade order-flow snapshot.
    """
    if df5 is None or df5.empty:
        return 0.0

    count = max(1, int(lookback))
    recent = df5.tail(count)
    total_base = pd.to_numeric(recent["volume"], errors="coerce")
    buy_base = pd.to_numeric(recent["taker_buy_base"], errors="coerce")

    valid = total_base.notna() & buy_base.notna()
    if not valid.any():
        return 0.0

    total_base = total_base[valid].clip(lower=0.0)
    buy_base = buy_base[valid].clip(lower=0.0)
    # Guard against occasional malformed data; taker buy cannot exceed total.
    buy_base = pd.Series(
        np.minimum(buy_base.to_numpy(), total_base.to_numpy()),
        index=total_base.index,
    )
    candle_delta = (2.0 * buy_base) - total_base
    return float(candle_delta.sum())


# ================= STRUCTURE =================
def structure(df4, df1, side):
    c4 = float(df4["close"].iloc[-1])
    c1 = float(df1["close"].iloc[-1])

    h4 = df4["high"].iloc[-20:-1]
    l4 = df4["low"].iloc[-20:-1]
    h1 = df1["high"].iloc[-20:-1]
    l1 = df1["low"].iloc[-20:-1]

    if side == "LONG":
        return (
            c4 > float(h4.max()) or c4 > float(df4["close"].iloc[-5]),
            c1 > float(h1.max()) or c1 > float(df1["close"].iloc[-5]),
        )

    return (
        c4 < float(l4.min()) or c4 < float(df4["close"].iloc[-5]),
        c1 < float(l1.min()) or c1 < float(df1["close"].iloc[-5]),
    )


# ================= INDEPENDENT DIRECTION INTELLIGENCE =================
def _direction_tf_score(df, lookback=DIRECTION_STRUCTURE_LOOKBACK):
    """Score closed-candle trend, EMA slope and range breakout. Positive=bullish."""
    if df is None or len(df) < max(DIRECTION_TREND_EMA_SLOW + 5, lookback + 3):
        return 0, {"ready": False}

    close = df["close"].astype(float)
    high = df["high"].astype(float)
    low = df["low"].astype(float)
    ema_fast = close.ewm(span=DIRECTION_TREND_EMA_FAST, adjust=False).mean()
    ema_slow = close.ewm(span=DIRECTION_TREND_EMA_SLOW, adjust=False).mean()
    last_close = float(close.iloc[-1])
    score = 0

    if ema_fast.iloc[-1] > ema_slow.iloc[-1]:
        score += 1
        alignment = "BULL"
    elif ema_fast.iloc[-1] < ema_slow.iloc[-1]:
        score -= 1
        alignment = "BEAR"
    else:
        alignment = "FLAT"

    if last_close > float(ema_slow.iloc[-1]):
        score += 1
        location = "ABOVE"
    elif last_close < float(ema_slow.iloc[-1]):
        score -= 1
        location = "BELOW"
    else:
        location = "AT"

    slope_ref = min(5, len(df) - 1)
    slope = float(ema_slow.iloc[-1] - ema_slow.iloc[-1 - slope_ref])
    if slope > 0:
        score += 1
        slope_label = "UP"
    elif slope < 0:
        score -= 1
        slope_label = "DOWN"
    else:
        slope_label = "FLAT"

    prior_high = float(high.iloc[-lookback-1:-1].max())
    prior_low = float(low.iloc[-lookback-1:-1].min())
    if last_close > prior_high:
        score += 2
        breakout = "BULL_BREAK"
    elif last_close < prior_low:
        score -= 2
        breakout = "BEAR_BREAK"
    else:
        breakout = "INSIDE_RANGE"

    return score, {
        "ready": True, "score": score, "ema_alignment": alignment,
        "close_vs_ema50": location, "ema50_slope": slope_label,
        "range_break": breakout,
    }


def direction_intelligence(df4, df1, df15):
    """Weighted 4H/1H/15M direction view; never blocks or changes a signal."""
    if not DIRECTION_INTEL_ENABLED:
        return {"direction": "DISABLED", "confidence": 0, "scores": {}, "details": {}}

    s4, d4 = _direction_tf_score(df4)
    s1, d1 = _direction_tf_score(df1)
    s15, d15 = _direction_tf_score(df15)
    weighted = 2 * s4 + 2 * s1 + s15

    if weighted >= 5 and s4 > 0 and s1 > 0:
        direction = "BUY"
    elif weighted <= -5 and s4 < 0 and s1 < 0:
        direction = "SELL"
    else:
        direction = "MIXED / NO CLEAR DIRECTION"

    confidence = int(round(min(100, abs(weighted) / 25 * 100)))
    return {
        "direction": direction, "confidence": confidence,
        "weighted_score": weighted,
        "scores": {"4H": s4, "1H": s1, "15M": s15},
        "details": {"4H": d4, "1H": d1, "15M": d15},
    }


# ================= SIGNAL ENGINE =================
def evaluate(client, symbol) -> Optional[Signal]:
    try:
        df15 = kline_df(client.klines(symbol, "15m", 120))
        df5 = kline_df(client.klines(symbol, "5m", 100))
        df1 = kline_df(client.klines(symbol, "1h", 250))
        df4 = kline_df(client.klines(symbol, "4h", 80))

        # Closed candles only.
        df15 = df15.iloc[:-1].copy()
        df5 = df5.iloc[:-1].copy()
        df1 = df1.iloc[:-1].copy()
        df4 = df4.iloc[:-1].copy()

        vp = volume_profile(df15, VP_BINS, VP_VALUE_AREA)
        if not vp:
            return reject(symbol, "VP_INVALID")

        last = df15.iloc[-1]
        prev = df15.iloc[-2]
        last5 = df5.iloc[-1]
        prev5 = df5.iloc[-2]

        a = float(atr(df15).iloc[-1])
        if not np.isfinite(a) or a <= 0:
            return reject(symbol, "ATR_INVALID")

        price = float(last["close"])

        # Independent direction assessment: logging only, not a signal filter.
        direction_view = direction_intelligence(df4, df1, df15)
        log.info(
            "DIRECTION INTEL | %s | direction=%s | confidence=%d%% | "
            "weighted=%s | TF_scores=%s | 4H=%s | 1H=%s | 15M=%s",
            symbol, direction_view.get("direction", "UNKNOWN"),
            direction_view.get("confidence", 0),
            direction_view.get("weighted_score", "n/a"),
            direction_view.get("scores", {}),
            direction_view.get("details", {}).get("4H", {}),
            direction_view.get("details", {}).get("1H", {}),
            direction_view.get("details", {}).get("15M", {}),
        )

        trades = client.agg_trades(symbol, 1000)
        _, _, delta = trade_flow(trades)
        imbalances = footprint_imbalances(trades)
        # CVD is calculated independently from the latest closed 5m candles.
        current_cvd = cvd(df5)
        log.debug(
            "CVD CHECK (different windows; raw magnitudes are not directly comparable) | %s | lookback=%d closed_5m | recent_1000_trade_delta=%.8g | "
            "candle_cvd_base=%.8g",
            symbol, CVD_LOOKBACK_5M, delta, current_cvd,
        )

        buy_imb = [x for x in imbalances if x[0] == "BUY"]
        sell_imb = [x for x in imbalances if x[0] == "SELL"]

        # VP location/reaction.
        bull_rejection = (
            float(prev["low"]) <= vp["val"]
            and price > vp["val"]
        )
        bear_rejection = (
            float(prev["high"]) >= vp["vah"]
            and price < vp["vah"]
        )

        bull_acceptance = (
            float(prev["close"]) > vp["vah"]
            and price > vp["vah"]
        )
        bear_acceptance = (
            float(prev["close"]) < vp["val"]
            and price < vp["val"]
        )

        # Order-flow concepts.
        bull_absorption = bool(sell_imb) and delta <= 0 and price >= float(prev["close"])
        bear_absorption = bool(buy_imb) and delta >= 0 and price <= float(prev["close"])

        bull_initiation = bool(buy_imb) and delta > 0 and price > float(prev["high"])
        bear_initiation = bool(sell_imb) and delta < 0 and price < float(prev["low"])

        # Additional acceptance-pressure path:
        # price has accepted outside the value area and recent aggressive
        # order flow agrees with the direction. The later 5m candle, HTF,
        # S/R+EMA, score, and structural SL filters still have to pass.
        bull_acceptance_pressure = (
            bull_acceptance and bool(buy_imb) and delta > 0
        )
        bear_acceptance_pressure = (
            bear_acceptance and bool(sell_imb) and delta < 0
        )

        # POC bounce route: permit a modest approach zone around POC while
        # still requiring a close across POC plus directionally aligned flow.
        # This is less brittle than requiring the current close to be within
        # only 0.35 ATR, without making order flow optional.
        poc_zone_atr = 0.60
        poc_near = abs(price - vp["poc"]) <= poc_zone_atr * a
        prev_close = float(prev["close"])
        bull_poc_bounce = (
            poc_near
            and prev_close <= vp["poc"]
            and price > vp["poc"]
            and bool(buy_imb)
            and delta > 0
        )
        bear_poc_bounce = (
            poc_near
            and prev_close >= vp["poc"]
            and price < vp["poc"]
            and bool(sell_imb)
            and delta < 0
        )

        # Controlled test route: absorption is accepted only when it occurs
        # near a meaningful Volume Profile reference (VAL/POC for longs,
        # VAH/POC for shorts). Order-flow confirmation is still mandatory.
        absorption_zone = max(0.0, VP_OF_ABSORPTION_ZONE_ATR) * a
        near_val_absorption = abs(price - vp["val"]) <= absorption_zone
        near_vah_absorption = abs(price - vp["vah"]) <= absorption_zone
        near_poc_absorption = abs(price - vp["poc"]) <= absorption_zone
        bull_absorption_zone = bull_absorption and (
            near_val_absorption or near_poc_absorption
        )
        bear_absorption_zone = bear_absorption and (
            near_vah_absorption or near_poc_absorption
        )

        # A genuine initiation is itself a valid VP/OF trigger: price has
        # broken the previous 15m candle's extreme and aggressive flow agrees.
        # Previously initiation only counted when VA acceptance was also true,
        # so strong events such as bear_init=True could still be rejected.
        # Setup paths are explicit and require a meaningful VP event plus
        # directional order-flow evidence. Acceptance can also be valid when
        # opposing aggressive flow is being absorbed at the accepted level.
        bull_rejection_flow = bull_rejection and (
            bull_absorption or (bool(buy_imb) and delta > 0)
        )
        bear_rejection_flow = bear_rejection and (
            bear_absorption or (bool(sell_imb) and delta < 0)
        )
        bull_acceptance_absorption = bull_acceptance and bull_absorption
        bear_acceptance_absorption = bear_acceptance and bear_absorption

        long_setup = (
            bull_rejection_flow
            or bull_initiation
            or bull_acceptance_pressure
            or bull_acceptance_absorption
            or bull_poc_bounce
            or bull_absorption_zone
        )
        short_setup = (
            bear_rejection_flow
            or bear_initiation
            or bear_acceptance_pressure
            or bear_acceptance_absorption
            or bear_poc_bounce
            or bear_absorption_zone
        )

        if long_setup == short_setup:
            # Diagnostics only: expose the existing VP/OF booleans without
            # changing any setup conditions or scoring.
            log.info(
                "VP_OF DETAIL | %s | price=%.8g | prev_close=%.8g | "
                "prev_low=%.8g | prev_high=%.8g | VAL=%.8g | POC=%.8g | VAH=%.8g | "
                "delta=%.8g | buy_imb=%d | sell_imb=%d | "
                "bull_rej=%s | bear_rej=%s | bull_acc=%s | bear_acc=%s | "
                "bull_abs=%s | bear_abs=%s | bull_init=%s | bear_init=%s | "
                "bull_rej_flow=%s | bear_rej_flow=%s | "
                "bull_acc_abs=%s | bear_acc_abs=%s | "
                "bull_acc_pressure=%s | bear_acc_pressure=%s | "
                "poc_zone_atr=%.2f | bull_poc_bounce=%s | bear_poc_bounce=%s | "
                "abs_zone_atr=%.2f | bull_abs_zone=%s | bear_abs_zone=%s | "
                "long_setup=%s | short_setup=%s | reason=%s",
                symbol, price, float(prev["close"]), float(prev["low"]),
                float(prev["high"]), vp["val"], vp["poc"], vp["vah"], delta,
                len(buy_imb), len(sell_imb), bull_rejection, bear_rejection,
                bull_acceptance, bear_acceptance, bull_absorption, bear_absorption,
                bull_initiation, bear_initiation,
                bull_rejection_flow, bear_rejection_flow,
                bull_acceptance_absorption, bear_acceptance_absorption,
                bull_acceptance_pressure, bear_acceptance_pressure,
                poc_zone_atr, bull_poc_bounce, bear_poc_bounce,
                VP_OF_ABSORPTION_ZONE_ATR, bull_absorption_zone, bear_absorption_zone,
                long_setup, short_setup,
                "both_true" if long_setup and short_setup else "both_false",
            )
            return reject(symbol, "VP_OF_NO_UNIQUE_SETUP")

        side = "LONG" if long_setup else "SHORT"

        s4, s1 = structure(df4, df1, side)

        # Avoid a completely opposite higher-timeframe environment.
        if not s4 and not s1:
            return reject(symbol, "HTF_STRUCTURE")

        score = 0
        structure_reason = (
            f"4H={'aligned' if s4 else 'neutral'} | "
            f"1H={'aligned' if s1 else 'neutral'}"
        )
        score += 10 if s4 else 5
        score += 10 if s1 else 5

        # VP: 25
        vp_points = 0
        vp_reason = []

        if side == "LONG":
            if bull_rejection:
                vp_points += 15
                vp_reason.append("VAL rejection")
            if bull_acceptance:
                vp_points += 12
                vp_reason.append("VAH acceptance")
            if bull_initiation:
                vp_points += 10
                vp_reason.append("bullish range initiation")
            if bull_poc_bounce:
                vp_points += 8
                vp_reason.append("POC bullish bounce")
            if bull_absorption_zone:
                vp_points += 8
                vp_reason.append("bullish absorption at VAL/POC zone")
        else:
            if bear_rejection:
                vp_points += 15
                vp_reason.append("VAH rejection")
            if bear_acceptance:
                vp_points += 12
                vp_reason.append("VAL acceptance")
            if bear_initiation:
                vp_points += 10
                vp_reason.append("bearish range initiation")
            if bear_poc_bounce:
                vp_points += 8
                vp_reason.append("POC bearish bounce")
            if bear_absorption_zone:
                vp_points += 8
                vp_reason.append("bearish absorption at VAH/POC zone")

        if abs(price - vp["poc"]) <= 0.35 * a:
            vp_points += 8
            vp_reason.append("POC location")

        if (
            abs(price - vp["val"]) <= 0.35 * a
            or abs(price - vp["vah"]) <= 0.35 * a
        ):
            vp_points += 5
            vp_reason.append("VA boundary")

        score += min(vp_points, 25)

        # Order flow: 30
        of_points = 0
        of_reason = []

        if side == "LONG":
            if bull_absorption:
                of_points += 15
                of_reason.append("bullish absorption")
            if bull_acceptance_absorption:
                of_reason.append("VAH acceptance with sell absorption")
            if bull_initiation:
                of_points += 12
                of_reason.append("bullish initiation")
            elif bull_acceptance_pressure:
                of_points += 10
                of_reason.append("bullish acceptance pressure")
            elif bull_poc_bounce:
                of_points += 10
                of_reason.append("bullish POC bounce pressure")
            if buy_imb:
                of_points += 8
                of_reason.append("3x buy imbalance")
        else:
            if bear_absorption:
                of_points += 15
                of_reason.append("bearish absorption")
            if bear_acceptance_absorption:
                of_reason.append("VAL acceptance with buy absorption")
            if bear_initiation:
                of_points += 12
                of_reason.append("bearish initiation")
            elif bear_acceptance_pressure:
                of_points += 10
                of_reason.append("bearish acceptance pressure")
            elif bear_poc_bounce:
                of_points += 10
                of_reason.append("bearish POC bounce pressure")
            if sell_imb:
                of_points += 8
                of_reason.append("3x sell imbalance")

        score += min(of_points, 30)

        # CVD: confirmation, not standalone trigger.
        cvd_aligned = (side == "LONG" and current_cvd > 0) or (
            side == "SHORT" and current_cvd < 0
        )
        if cvd_aligned:
            score += 5
        cvd_reason = "aligned" if cvd_aligned else "not aligned"

        # 5M closed candle confirmation.
        bull5 = (
            float(last5["close"]) > float(last5["open"])
            and float(last5["close"]) > float(prev5["high"])
        )
        bear5 = (
            float(last5["close"]) < float(last5["open"])
            and float(last5["close"]) < float(prev5["low"])
        )

        if side == "LONG" and not bull5:
            return reject(symbol, "5M_CANDLE_CONFIRMATION")
        if side == "SHORT" and not bear5:
            return reject(symbol, "5M_CANDLE_CONFIRMATION")

        score += 5
        candle_reason = "5M closed-candle confirmation"

        # ================= S/R + EMA SUPPORT CONFIRMATION =================
        # This is integrated into the main engine, not a separate bot.
        # Use only closed candles. Baseline VP + Order Flow setup remains intact.
        sr_ema_reason = "disabled"
        if SR_EMA_ENABLED:
            if len(df1) < 205 or len(df5) < 55 or len(df15) < 25:
                log.info(
                    "REJECT SR_EMA_DATA | %s | closed_1h=%d (need>=205) | "
                    "closed_5m=%d (need>=55) | closed_15m=%d (need>=25)",
                    symbol, len(df1), len(df5), len(df15)
                )
                return reject(symbol, "SR_EMA_DATA")

            ema20_5 = float(df5["close"].ewm(span=20, adjust=False).mean().iloc[-1])
            ema50_5 = float(df5["close"].ewm(span=50, adjust=False).mean().iloc[-1])
            ema200_1 = float(df1["close"].ewm(span=200, adjust=False).mean().iloc[-1])
            close1 = float(df1["close"].iloc[-1])
            ema_aligned = (
                close1 > ema200_1 and ema20_5 > ema50_5
                if side == "LONG" else
                close1 < ema200_1 and ema20_5 < ema50_5
            )

            # Find confirmed 15m swing support/resistance from closed candles.
            recent = df15.tail(SR_LOOKBACK_15M).reset_index(drop=True)
            highs = recent["high"].astype(float).to_numpy()
            lows = recent["low"].astype(float).to_numpy()
            supports, resistances = [], []
            for i in range(2, len(recent) - 2):
                if lows[i] <= min(lows[i-2:i+3]) and lows[i] < price:
                    supports.append(float(lows[i]))
                if highs[i] >= max(highs[i-2:i+3]) and highs[i] > price:
                    resistances.append(float(highs[i]))

            near_threshold = max(SR_NEAR_ATR * a, price * 0.001)
            # Reaction requires price near the appropriate S/R level and a
            # confirmed bullish/bearish 5m close (baseline candle check above).
            nearest_support = max(supports) if supports else None
            nearest_resistance = min(resistances) if resistances else None
            sr_reaction = False
            if side == "LONG" and nearest_support is not None:
                sr_reaction = (
                    abs(price - nearest_support) <= near_threshold
                    and float(last5["close"]) > float(last5["open"])
                )
            elif side == "SHORT" and nearest_resistance is not None:
                sr_reaction = (
                    abs(nearest_resistance - price) <= near_threshold
                    and float(last5["close"]) < float(last5["open"])
                )

            # Supporting layer: allow the setup when EMA trend OR an S/R
            # reaction confirms it; do not require both, to avoid over-filtering.
            if not (ema_aligned or sr_reaction):
                log.info(
                    "REJECT SR_EMA_CONFIRMATION | %s | side=%s | ema_aligned=%s | "
                    "sr_reaction=%s | support=%s | resistance=%s | threshold=%.8g",
                    symbol, side, ema_aligned, sr_reaction,
                    nearest_support, nearest_resistance, near_threshold,
                )
                REJECT_COUNTS["SR_EMA_CONFIRMATION"] += 1
                return None

            sr_ema_reason = (
                f"EMA={'aligned' if ema_aligned else 'not aligned'}; "
                f"S/R={'reaction' if sr_reaction else 'no reaction'}"
            )
            log.info(
                "SR_EMA_PASS | %s | %s | %s | EMA20_5m=%.8g | EMA50_5m=%.8g | "
                "EMA200_1h=%.8g | support=%s | resistance=%s",
                symbol, side, sr_ema_reason, ema20_5, ema50_5, ema200_1,
                nearest_support, nearest_resistance,
            )

        # ================= SL / TP =================
        # Keep the existing signal engine and filters unchanged.
        # Improve only the stop placement: use the nearest confirmed 15m swing
        # beyond entry, then place the stop beyond it by an ATR/price buffer.
        # A pivot is considered confirmed only after two closed candles on its right.
        recent_structure = df15.tail(max(5, SR_LOOKBACK_15M)).reset_index(drop=True)
        structure_highs = recent_structure["high"].astype(float).to_numpy()
        structure_lows = recent_structure["low"].astype(float).to_numpy()
        swing_lows = []
        swing_highs = []
        for i in range(2, len(recent_structure) - 2):
            local_lows = structure_lows[i - 2:i + 3]
            local_highs = structure_highs[i - 2:i + 3]
            if structure_lows[i] <= float(np.min(local_lows)) and structure_lows[i] < price:
                swing_lows.append(float(structure_lows[i]))
            if structure_highs[i] >= float(np.max(local_highs)) and structure_highs[i] > price:
                swing_highs.append(float(structure_highs[i]))

        # Preserve a safe fallback when no confirmed pivot is available.
        atr_buffer = max(float(a) * SL_ATR_BUFFER, price * 0.0005)
        if side == "LONG":
            if swing_lows:
                raw_structure = max(swing_lows)  # closest confirmed swing low below entry
                sl_basis = "confirmed_15m_swing_low"
            else:
                raw_structure = float(recent_structure["low"].tail(5).min())
                sl_basis = "fallback_recent_15m_low"
            sl = raw_structure - atr_buffer
            risk_distance = price - sl
            tp = price + MIN_RR * risk_distance
        else:
            if swing_highs:
                raw_structure = min(swing_highs)  # closest confirmed swing high above entry
                sl_basis = "confirmed_15m_swing_high"
            else:
                raw_structure = float(recent_structure["high"].tail(5).max())
                sl_basis = "fallback_recent_15m_high"
            sl = raw_structure + atr_buffer
            risk_distance = sl - price
            tp = price - MIN_RR * risk_distance

        if risk_distance <= 0:
            return reject(symbol, "SL_INVALID_DISTANCE")

        sl_pct = risk_distance / price * 100.0
        log.info(
            "SL DETAIL | %s | %s | entry=%.8g | final_sl=%.8g | "
            "sl_pct=%.3f%% | max=%.3f%% | basis=%s",
            symbol, side, price, sl, sl_pct, MAX_SL_PCT, sl_basis
        )
        log.info(
            "SL STRUCTURE | %s | basis=%s | raw_structure=%.8g | "
            "ATR=%.8g | buffer_mult=%.2f | actual_buffer=%.8g | "
            "final_sl=%.8g | TP=%.8g | RR=%.2f",
            symbol, sl_basis, raw_structure, a, SL_ATR_BUFFER,
            atr_buffer, sl, tp, MIN_RR
        )

        if sl_pct > MAX_SL_PCT:
            log.info(
                "SL REJECT | %s | %s | %.3f%% > %.3f%%",
                symbol, side, sl_pct, MAX_SL_PCT
            )
            REJECT_COUNTS["SL_OVER_MAX_PCT"] += 1
            return None

        score += 5  # RR quality
        if score < MIN_SCORE:
            return reject(symbol, "SCORE_BELOW_MIN")

        risk_usdt = PAPER_WALLET_USDT * RISK_PCT / 100.0
        rr = abs(tp - price) / risk_distance

        setup = "REVERSAL" if (
            bull_rejection or bear_rejection
        ) else "CONTINUATION"

        return Signal(
            symbol=symbol,
            side=side,
            score=score,
            setup=setup,
            entry=price,
            sl=sl,
            tp=tp,
            rr=rr,
            vp_reason=", ".join(vp_reason) or "VP location",
            of_reason=", ".join(of_reason) or "order flow",
            cvd_reason=cvd_reason,
            structure_reason=structure_reason,
            candle_reason=candle_reason,
            delta=delta,
            cvd=current_cvd,
            risk_usdt=risk_usdt,
        )

    except Exception as exc:
        REJECT_COUNTS["EVALUATION_ERROR"] += 1
        log.warning("REJECT EVALUATION_ERROR | %s | %s", symbol, exc)
        return None



# ================= TELEGRAM DUPLICATE RANGE LOCK =================
def _load_signal_range_locks():
    try:
        with open(SIGNAL_RANGE_LOCK_FILE, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except FileNotFoundError:
        return {}
    except Exception as exc:
        log.warning("SIGNAL RANGE LOCK | load failed: %s", exc)
        return {}


def _save_signal_range_locks(locks):
    try:
        temp_path = SIGNAL_RANGE_LOCK_FILE + ".tmp"
        with open(temp_path, "w", encoding="utf-8") as handle:
            json.dump(locks, handle, indent=2)
        os.replace(temp_path, SIGNAL_RANGE_LOCK_FILE)
    except Exception as exc:
        log.warning("SIGNAL RANGE LOCK | save failed: %s", exc)


def _signal_lock_key(signal):
    return f"{signal.symbol}:{signal.side}"


def _inside_active_range(price, lock):
    """True while mark price remains within +/- configured % of original entry."""
    entry = float(lock["entry"])
    if entry <= 0:
        return False
    band = max(0.0, float(SIGNAL_RANGE_LOCK_PCT)) / 100.0
    lower = entry * (1.0 - band)
    upper = entry * (1.0 + band)
    return lower <= float(price) <= upper


def _current_mark_price(client, symbol):
    try:
        result = client.get("/fapi/v1/premiumIndex", {"symbol": symbol})
        return float(result["markPrice"])
    except Exception as exc:
        log.warning("SIGNAL RANGE LOCK | price lookup failed %s: %s", symbol, exc)
        return None


def signal_range_is_locked(client, signal, locks):
    if not SIGNAL_RANGE_LOCK_ENABLED:
        return False
    key = _signal_lock_key(signal)
    lock = locks.get(key)
    if not lock:
        return False

    current = _current_mark_price(client, signal.symbol)
    if current is None:
        # Avoid alert spam if we cannot safely determine whether the old range ended.
        log.info("SIGNAL RANGE LOCK | SUPPRESS %s | current price unavailable", key)
        return True

    if _inside_active_range(current, lock):
        log.info(
            "SIGNAL RANGE LOCK | SUPPRESS %s | mark=%.8g | entry=%.8g | band=+/-%.2f%% | lower=%.8g | upper=%.8g",
            key, current, float(lock["entry"]), SIGNAL_RANGE_LOCK_PCT,
            float(lock["entry"]) * (1.0 - max(0.0, SIGNAL_RANGE_LOCK_PCT) / 100.0),
            float(lock["entry"]) * (1.0 + max(0.0, SIGNAL_RANGE_LOCK_PCT) / 100.0)
        )
        return True

    log.info(
        "SIGNAL RANGE LOCK | RELEASE %s | mark=%.8g outside entry +/- %.2f%% band",
        key, current, SIGNAL_RANGE_LOCK_PCT
    )
    locks.pop(key, None)
    _save_signal_range_locks(locks)
    return False


def remember_signal_range(signal, locks):
    if not SIGNAL_RANGE_LOCK_ENABLED:
        return
    key = _signal_lock_key(signal)
    locks[key] = {
        "symbol": signal.symbol, "side": signal.side,
        "entry": float(signal.entry), "sl": float(signal.sl), "tp": float(signal.tp),
        "created_at": time.time(),
    }
    _save_signal_range_locks(locks)
    log.info(
        "SIGNAL RANGE LOCK | SET %s | entry=%.8g | SL=%.8g | TP=%.8g",
        key, signal.entry, signal.sl, signal.tp
    )



# ================= PAPER TRADE TRACKER =================
PAPER_CSV_FIELDS = [
    "signal_id", "symbol", "side", "setup", "score", "signal_time",
    "entry", "sl", "tp", "rr", "risk_usdt", "status", "close_time",
    "exit_price", "result_r", "pnl_usdt", "close_reason", "max_favorable_pct",
    "max_adverse_pct",
]


def _paper_load_state():
    try:
        with open(PAPER_TRACKING_STATE, "r", encoding="utf-8") as f:
            state = json.load(f)
        if not isinstance(state, dict):
            return {"active": {}, "summary": {}}
        state.setdefault("active", {})
        state.setdefault("summary", {})
        return state
    except FileNotFoundError:
        return {"active": {}, "summary": {}}
    except Exception as exc:
        log.warning("PAPER TRACKER | state load failed: %s", exc)
        return {"active": {}, "summary": {}}


def _paper_save_state(state):
    try:
        os.makedirs(PAPER_TRACKING_DIR, exist_ok=True)
        tmp = PAPER_TRACKING_STATE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2)
        os.replace(tmp, PAPER_TRACKING_STATE)
    except Exception as exc:
        log.error("PAPER TRACKER | state save failed: %s", exc)


def _paper_init_csv():
    os.makedirs(PAPER_TRACKING_DIR, exist_ok=True)
    if not os.path.exists(PAPER_TRACKING_CSV) or os.path.getsize(PAPER_TRACKING_CSV) == 0:
        with open(PAPER_TRACKING_CSV, "w", newline="", encoding="utf-8") as f:
            csv.DictWriter(f, fieldnames=PAPER_CSV_FIELDS).writeheader()


def _paper_append_row(row):
    try:
        _paper_init_csv()
        with open(PAPER_TRACKING_CSV, "a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=PAPER_CSV_FIELDS, extrasaction="ignore")
            writer.writerow(row)
    except Exception as exc:
        log.error("PAPER TRACKER | CSV write failed: %s", exc)


def _paper_fetch_1m(client, symbol, start_time_ms):
    raw = client.klines(symbol, "1m", 1000)
    df = kline_df(raw)
    now_ms = int(time.time() * 1000)
    # Ignore the currently forming candle and any candle before entry time.
    df = df[(df["open_time"] >= start_time_ms) & (df["close_time"] < now_ms)].copy()
    return df


def _paper_result_summary(state):
    rows = []
    try:
        with open(PAPER_TRACKING_CSV, "r", newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
    except Exception:
        pass
    closed = [r for r in rows if r.get("status") == "CLOSED"]
    wins = [r for r in closed if float(r.get("pnl_usdt") or 0) > 0]
    losses = [r for r in closed if float(r.get("pnl_usdt") or 0) < 0]
    total_r = sum(float(r.get("result_r") or 0) for r in closed)
    total_pnl = sum(float(r.get("pnl_usdt") or 0) for r in closed)
    win_rate = 100.0 * len(wins) / len(closed) if closed else 0.0
    return {
        "closed": len(closed), "wins": len(wins), "losses": len(losses),
        "win_rate": win_rate, "total_r": total_r, "total_pnl": total_pnl,
    }


def _paper_start_trade(signal, state):
    if not PAPER_TRACKING_ENABLED:
        return
    key = f"{signal.symbol}:{signal.side}"
    # Allow concurrent paper trades on different symbol/side keys.
    # Prevent overwriting a still-active trade for the exact same symbol+side.
    if key in state["active"]:
        log.info("PAPER TRACKER | same symbol/side already active; skip opening %s", key)
        return
    risk_usdt = PAPER_WALLET_USDT * PAPER_TRACKING_RISK_PCT / 100.0
    entry = float(signal.entry)
    sl_distance = abs(entry - float(signal.sl))
    if entry <= 0 or sl_distance <= 0:
        log.warning("PAPER TRACKER | invalid entry/SL; not tracking %s", key)
        return
    qty = risk_usdt / sl_distance
    trade = {
        "signal_id": f"{signal.symbol}:{signal.side}:{int(time.time() * 1000)}",
        "symbol": signal.symbol, "side": signal.side, "setup": signal.setup,
        "score": int(signal.score), "signal_time": time.time(),
        "entry": entry, "sl": float(signal.sl), "tp": float(signal.tp),
        "rr": float(signal.rr), "risk_usdt": risk_usdt, "qty": qty,
        "status": "OPEN", "max_favorable_pct": 0.0, "max_adverse_pct": 0.0,
    }
    state["active"][key] = trade
    _paper_append_row({
        **trade, "signal_time": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime(trade["signal_time"])),
        "close_time": "", "exit_price": "", "result_r": "", "pnl_usdt": "",
        "close_reason": "",
    })
    _paper_save_state(state)
    log.info(
        "PAPER TRACKER | OPEN %s | entry=%.8g | SL=%.8g | TP=%.8g | risk=%.2f USDT",
        key, entry, signal.sl, signal.tp, risk_usdt
    )


def _paper_close_trade(trade, state, exit_price, reason):
    entry = float(trade["entry"])
    sl = float(trade["sl"])
    risk_dist = abs(entry - sl)
    qty = float(trade["qty"])
    if trade["side"] == "LONG":
        pnl = (float(exit_price) - entry) * qty
    else:
        pnl = (entry - float(exit_price)) * qty
    result_r = pnl / float(trade["risk_usdt"]) if float(trade["risk_usdt"]) else 0.0
    close_time = time.time()

    _paper_append_row({
        "signal_id": trade["signal_id"], "symbol": trade["symbol"], "side": trade["side"],
        "setup": trade["setup"], "score": trade["score"],
        "signal_time": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime(trade["signal_time"])),
        "entry": entry, "sl": sl, "tp": trade["tp"], "rr": trade["rr"],
        "risk_usdt": trade["risk_usdt"], "status": "CLOSED",
        "close_time": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime(close_time)),
        "exit_price": float(exit_price), "result_r": round(result_r, 4),
        "pnl_usdt": round(pnl, 4), "close_reason": reason,
        "max_favorable_pct": trade.get("max_favorable_pct", 0.0),
        "max_adverse_pct": trade.get("max_adverse_pct", 0.0),
    })

    key = f"{trade['symbol']}:{trade['side']}"
    state["active"].pop(key, None)
    summary = _paper_result_summary(state)
    _paper_save_state(state)
    telegram_send(
        "📒 <b>PAPER TRADE CLOSED</b>\n"
        f"{trade['symbol']} | {trade['side']}\n"
        f"Reason: <b>{reason}</b>\n"
        f"Entry: <code>{entry:.8g}</code> | Exit: <code>{float(exit_price):.8g}</code>\n"
        f"Paper P/L: <b>{pnl:+.2f} USDT</b> ({result_r:+.2f}R)\n"
        f"Closed trades: {summary['closed']} | Win rate: {summary['win_rate']:.1f}%\n"
        f"Total paper P/L: {summary['total_pnl']:+.2f} USDT | Total R: {summary['total_r']:+.2f}\n"
        "⚠️ PAPER ONLY — NO ORDERS PLACED"
    )
    log.info(
        "PAPER TRACKER | CLOSED %s | reason=%s | pnl=%.4f | R=%.3f | closed=%d | win_rate=%.1f%%",
        key, reason, pnl, result_r, summary["closed"], summary["win_rate"]
    )


def _paper_monitor(client, state):
    if not PAPER_TRACKING_ENABLED or not state["active"]:
        return
    now = time.time()
    for key, trade in list(state["active"].items()):
        try:
            entry_ms = int(float(trade["signal_time"]) * 1000)
            df = _paper_fetch_1m(client, trade["symbol"], entry_ms)
            if df.empty:
                if now - float(trade["signal_time"]) >= PAPER_TRACKING_MAX_HOURS * 3600:
                    _paper_close_trade(trade, state, float(trade["entry"]), "EXPIRED_NO_CLOSED_CANDLE")
                continue

            close_trade = None
            for _, candle in df.iterrows():
                hi, lo = float(candle["high"]), float(candle["low"])
                entry = float(trade["entry"])
                if trade["side"] == "LONG":
                    favorable = max(0.0, (hi - entry) / entry * 100.0)
                    adverse = max(0.0, (entry - lo) / entry * 100.0)
                    hit_sl = lo <= float(trade["sl"])
                    hit_tp = hi >= float(trade["tp"])
                else:
                    favorable = max(0.0, (entry - lo) / entry * 100.0)
                    adverse = max(0.0, (hi - entry) / entry * 100.0)
                    hit_sl = hi >= float(trade["sl"])
                    hit_tp = lo <= float(trade["tp"])
                trade["max_favorable_pct"] = max(float(trade.get("max_favorable_pct", 0)), favorable)
                trade["max_adverse_pct"] = max(float(trade.get("max_adverse_pct", 0)), adverse)

                # Conservative ambiguity rule: if TP and SL occur in the same
                # 1m candle, count SL first because intrabar order is unknown.
                if hit_sl:
                    close_trade = (float(trade["sl"]), "SL")
                    break
                if hit_tp:
                    close_trade = (float(trade["tp"]), "TP")
                    break

            if close_trade:
                _paper_close_trade(trade, state, close_trade[0], close_trade[1])
            elif now - float(trade["signal_time"]) >= PAPER_TRACKING_MAX_HOURS * 3600:
                last_close = float(df["close"].iloc[-1])
                _paper_close_trade(trade, state, last_close, "EXPIRED_24H_MARK_TO_MARKET")
            else:
                state["active"][key] = trade
                _paper_save_state(state)
        except Exception as exc:
            log.warning("PAPER TRACKER | monitor error %s | %s", key, exc)


def universe(client):
    info = client.exchange_info()
    allowed = {
        s["symbol"]
        for s in info["symbols"]
        if s["status"] == "TRADING"
        and s["contractType"] == "PERPETUAL"
        and s["quoteAsset"] == "USDT"
    }

    rows = [
        x for x in client.ticker_24h()
        if x["symbol"] in allowed
    ]
    rows.sort(key=lambda x: float(x["quoteVolume"]), reverse=True)
    return [x["symbol"] for x in rows[:MAX_SYMBOLS]]


def signal_message(s: Signal):
    side_label = "SHORT" if s.side == "SHORT" else "LONG"
    return (
        f"<b>{side_label} — {s.symbol}</b>\n"
        f"Entry: <code>{s.entry:.8g}</code>\n"
        f"TP: <code>{s.tp:.8g}</code>\n"
        f"SL: <code>{s.sl:.8g}</code>"
    )


def main():
    client = BinanceFutures()

    log.info("HYBRID V1 MAIN ENGINE | VP + Order Flow + CVD + S/R + EMA")
    log.info("SL MODE=CONFIRMED 15M SWING + ATR BUFFER | MAX_SL_PCT is a cap, not a fixed 5%% stop")
    log.info("S/R_EMA=%s | MAX_SL_PCT=%.2f%% | MIN_SCORE=%d | MIN_RR=%.2f | AUTO_TRADE=%s",
             SR_EMA_ENABLED, MAX_SL_PCT, MIN_SCORE, MIN_RR, AUTO_TRADE)
    log.info(
        "HYBRID V1 | symbols=%d | request_delay=%.2fs | "
        "min_score=%d | min_rr=%.2f | max_sl=%.2f%% | "
        "CVD_LOOKBACK_5M=%d | auto_trade=%s",
        MAX_SYMBOLS, REQUEST_DELAY, MIN_SCORE, MIN_RR, MAX_SL_PCT,
        CVD_LOOKBACK_5M, AUTO_TRADE
    )

    telegram_send(
        "🟢 <b>BINANCE HYBRID V1 STARTED</b>\n"
        "VP + Order Flow + rolling 5M CVD + 4H/1H + 5M\n"
        f"CVD lookback={CVD_LOOKBACK_5M} closed 5M candles\n"
        f"S/R+EMA={'ON' if SR_EMA_ENABLED else 'OFF'} | "
        f"MAX SL={MAX_SL_PCT:.2f}% | MIN SCORE={MIN_SCORE} | RR≥{MIN_RR} | "
        f"AUTO_TRADE={AUTO_TRADE}"
    )

    sent = {}
    signal_range_locks = _load_signal_range_locks()
    paper_state = _paper_load_state()
    _paper_init_csv()
    log.info("PAPER TRACKING=%s | csv=%s | state=%s", PAPER_TRACKING_ENABLED, PAPER_TRACKING_CSV, PAPER_TRACKING_STATE)
    log.info(
        "SIGNAL RANGE LOCK=%s | band=+/-%.2f%% from signal entry | state_file=%s",
        SIGNAL_RANGE_LOCK_ENABLED, SIGNAL_RANGE_LOCK_PCT, SIGNAL_RANGE_LOCK_FILE
    )

    while True:
        started = time.time()

        try:
            _paper_monitor(client, paper_state)
            symbols = universe(client)
            log.info("Scanning %d liquid USDT perpetuals...", len(symbols))

            qualified = 0
            REJECT_COUNTS.clear()

            for symbol in symbols:
                signal = evaluate(client, symbol)

                if not signal:
                    time.sleep(REQUEST_DELAY)
                    continue

                time.sleep(REQUEST_DELAY)

                qualified += 1

                # Multi-symbol mode: an active paper trade on another symbol
                # must not suppress this qualified signal.

                # Suppress same symbol+direction while price remains inside prior TP/SL range.
                if signal_range_is_locked(client, signal, signal_range_locks):
                    time.sleep(REQUEST_DELAY)
                    continue

                # Basic duplicate protection.
                key = (
                    signal.symbol,
                    signal.side,
                    signal.setup,
                    round(signal.entry, 6),
                )
                if key in sent:
                    continue

                sent[key] = time.time()

                log.info(
                    "SIGNAL | %s | %s | score=%d | entry=%s | SL=%s | TP=%s",
                    signal.symbol,
                    signal.side,
                    signal.score,
                    signal.entry,
                    signal.sl,
                    signal.tp,
                )

                telegram_send(signal_message(signal))
                # Persist the range lock to prevent repeat alerts across bot restarts.
                remember_signal_range(signal, signal_range_locks)
                _paper_start_trade(signal, paper_state)

            reject_summary = ", ".join(
                f"{reason}={count}" for reason, count in sorted(REJECT_COUNTS.items())
            ) or "none"
            log.info("REJECT SUMMARY | %s", reject_summary)
            log.info(
                "SCAN DONE | qualified=%d | elapsed=%.1fs",
                qualified,
                time.time() - started,
            )

        except requests.HTTPError as exc:
            response = getattr(exc, "response", None)
            if response is not None and response.status_code == 451:
                # Print Binance's actual explanation, rather than an unhelpful
                # repeated traceback. This diagnoses the block; it does not bypass it.
                body = (response.text or "").strip().replace("\n", " ")[:1000]
                log.error(
                    "BINANCE FUTURES HTTP 451 | endpoint=%s | body=%s | "
                    "Check Binance API access policy and the Railway service region/network. "
                    "No trading signals can be scanned until API access works.",
                    getattr(response.request, "url", BINANCE_BASE), body or "<empty response body>"
                )
            else:
                log.exception("Main scan HTTP error")
        except Exception:
            log.exception("Main scan error")

        elapsed = time.time() - started
        time.sleep(max(5, SCAN_SECONDS - elapsed))


if __name__ == "__main__":
    main()
